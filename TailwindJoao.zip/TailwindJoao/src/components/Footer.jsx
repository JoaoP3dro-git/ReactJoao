const Footer = () => {
    return (
        <div className='footer h-32 w-full bg-slate-950 flex justify-between p-12'/>
    )
}

export default Footer;